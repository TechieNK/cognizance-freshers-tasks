+++
title = "HTML and CSS courses"
date = "2020-11-24"
sidemenu = "true"
description = "Completion of HTML and CSS courses in Codecademy"
+++
# HTML and CSS course in Codecademy
For the final and last task, You have to complete the Courses in Codecademy
[HTML](https://www.codecademy.com/learn/learn-html)
and [CSS](https://www.codecademy.com/learn/learn-css)  
## These courses will be able to improve your imagination and creative mind.  
The HTML course is HTML (Hypertext Markup Language) is the code that is used to structure a web page and its content. For example, content could be structured within a set of paragraphs, a list of bulleted points, or using images and data tables.  
Click to join the course -> [HTML](https://www.codecademy.com/learn/learn-html)  

------
<!-- Horizontal Rule -->
The CSS stands for Cascading Style Sheets, CSS describes how HTML elements are to be displayed on screen, paper, or in other media
CSS saves a lot of work. It can control the layout of multiple web pages all at once, External stylesheets are stored in CSS files.  
Click to join the course -> [CSS](https://www.codecademy.com/learn/learn-css)

------
<!-- Horizontal Rule -->
**After completion of the courses take screenshot of the course completion and we will give a Google form to submit the screenshot.**

------
## SELF LEARNING project (Optional)   
	On completion of SELF LEARNING project the student will be directly admitted to 
	the club.
	
	NO need of purchasing the course for certification. 
	We will be evaluating you by conducting a contest.
	
	
