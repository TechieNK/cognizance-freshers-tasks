+++
title = "HTML and CSS courses"
date = "2020-11-24"
sidemenu = "true"
description = "Completion of HTML and CSS courses in Coursera"
+++
# HTML and CSS course in Coursera
For the final and last task, You have to complete the Courses in Coursera 
## These courses will be able to improve your imagination and creative mind.  
The HTML course is HTML (Hypertext Markup Language) is the code that is used to structure a web page and its content. For example, content could be structured within a set of paragraphs, a list of bulleted points, or using images and data tables.  
Click to join the course -> [HTML]()  

------
<!-- Horizontal Rule -->
The CSS stands for Cascading Style Sheets, CSS describes how HTML elements are to be displayed on screen, paper, or in other media
CSS saves a lot of work. It can control the layout of multiple web pages all at once, External stylesheets are stored in CSS files.  
Click to join the course -> [CSS]()

------

## Task

**After completion of the courses take screenshot of the course completion upload the screenshot in Task-7 folder in the Cognizance repository**
	
	No need of purchasing the course for certification. 


