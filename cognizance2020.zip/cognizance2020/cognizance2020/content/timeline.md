+++
title = "Timeline"
date = "2020-11-24"
sidemenu = "true"
description = "Timeline for task completion"
+++

## Commencement of tasks  
 
**Begins on > 30-11-2020**   

	You can start doing your tasks from now

------

## Git Setup  

**Deadline > 02-12-2020**  

    > Complete Git development environment

------

## Version Control System  

**Deadline > 04-12-2020**  

    > Local setup of Version Control System

------

## Operations on Git  

**Deadline > 08-12-2020**  

    > Getting familiar with Git operations like pull, 
      push, commit, merge, rebase, fork etc.,

------

## Markdown language  

**Deadline > 10-12-2020**  

    > Writing professional documents with markdown language

------

## Presentation skills  

**Deadline > 14-12-2020**  

    > Making professional presentation adhere to technical standards

------

## Pseudo code  

**Deadline > 18-12-2020**  

    > Writing pseudo code for basic logics

------

## HTML & CSS Course  

**Deadline > 29-12-2020**  

    > Completing HTML & CSS courses from Codecademy

------

