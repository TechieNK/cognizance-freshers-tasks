+++
title = "Timeline"
date = "2020-11-24"
sidemenu = "true"
description = "Timeline for task completion"
+++

**Commencement of tasks  			-  			30-11-2020**  
 You can start doing your tasks from now

------

**Git Setup  			-  			02-12-2020**  
Complete Git development environment

------

**Version Control System  			-  			04-12-2020**  
Local setup of Version Control System

------

**Operations on Git  			-  			08-12-2020**  
Getting familiar with Git operations like pull, push, commit, merge, rebase, fork etc.,

------

**Markdown language  			-  			10-12-2020**  
Writing professional documents with markdown language

------

**Presentation skills  			-  			14-12-2020**  
Making professional presentation adhere to technical standards

------

**Pseudo code  			-  			18-12-2020**  
Writing pseudo code for basic logics

------

**HTML & CSS Course  			-  			29-12-2020**  
Completing HTML & CSS courses from Codecademy

------

